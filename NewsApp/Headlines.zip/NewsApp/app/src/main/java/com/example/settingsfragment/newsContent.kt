package com.example.settingsfragment

data class newsContent (



        val title : String,
        val url : String,
        val imageUrl : String,


)